import { NgModule } from '@angular/core';
/*import { EventNamePipe } from './event-name/event-name';
import { AgentNamePipe } from './agent-name/agent-name';
import { AgencyNamePipe } from './agency-name/agency-name'; */
@NgModule({
	declarations: [/*EventNamePipe,AgentNamePipe,AgencyNamePipe*/],
	imports: [],
	exports: [/*EventNamePipe,AgentNamePipe,AgencyNamePipe*/]
})
export class PipesModule {}
