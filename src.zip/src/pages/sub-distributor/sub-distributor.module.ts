import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SubDistributorPage } from './sub-distributor';

@NgModule({
  declarations: [
    SubDistributorPage,
  ],
  imports: [
    IonicPageModule.forChild(SubDistributorPage),
  ],
})
export class SubDistributorPageModule {}
