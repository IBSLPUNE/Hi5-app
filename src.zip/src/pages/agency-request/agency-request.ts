import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController, AlertController, ToastController, ViewController  } from 'ionic-angular';
import { AuthServiceProvider } from '../../providers/auth-service/auth-service';
/**
 * Generated class for the AgencyRequestPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-agency-request',
  templateUrl: 'agency-request.html',
})
export class AgencyRequestPage {
   loading: any;
   county_type_data: Array<{ value: string, text: string }> = [];
   county_type: any;
   countytype: any;

   state_type_data: Array<{ value: string, text: string }> = [];
   state_type: any;
   statetype: any;

   district_type_data: Array<{ value: string, text: string }> = [];
   district_type: any;
   districttype: any;

   company_type_data: Array<{ value: string, text: string }> = [];
   company_type: any;
   companytype: any;


   Code: any;
   Name: any;
   fullName: any;
   Address: any;
   pinCode: any;
   City: any;
   contactNo: any;
   Email: any;
   Website: any;

   AgencyReq = { county_type: '', state_type: '', district_type: '', code: '', name: '', 
   full_name: '', address: '', pin_code: '', city: '', contact_no: '', email: '', website:'', company_type:'' };

  
  constructor(public navCtrl: NavController, public navParams: NavParams, private alertCtrl: AlertController, private authService: AuthServiceProvider, public loadingCtrl: LoadingController, private toastCtrl: ToastController, public viewCtrl: ViewController) {
       this.getCountyType();
  }

  ionViewDidLoad() {
  this.getCompanyType();
    console.log('ionViewDidLoad AgencyRequestPage');
  }
   compareFn(option1: any, option2: any) {
        return option1.value === option2.value;
    }

     getCountyType() {
      //  this.showLoader();
        this.authService.getCountyType().then((result) => {
          //  this.loading.dismiss();

            this.countytype = result;

            this.county_type_data.push({ value: '', text: 'Select County' });

            for (let i = 0; i < this.countytype.length; i++) {
                this.county_type_data.push({ value: this.countytype[i].id, text: this.countytype[i].name });
            }

            this.county_type = { text: 'Select County', value: '' };

            //this.getStateType();
        }, (err) => {
            this.loading.dismiss();
            let errJson = err.json();
            this.presentToast(errJson.message);
        });
    }
     getStateType() {
      //  this.showLoader();
        this.authService.getStateType(this.county_type.value).then((result) => {
           // this.loading.dismiss();

            this.statetype = result;

            this.state_type_data.push({ value: '', text: 'Select State' });

            for (let i = 0; i < this.statetype.length; i++) {
                this.state_type_data.push({ value: this.statetype[i].id, text: this.statetype[i].name });
            }

            this.state_type = { text: 'Select State', value: '' };

            //this.getDistrictType();
        }, (err) => {
            this.loading.dismiss();
            let errJson = err.json();
            this.presentToast(errJson.message);
        });
    }
     getDistrictType() {
      //  this.showLoader();
        this.authService.getDistrictType(this.state_type.value).then((result) => {
           // this.loading.dismiss();

            this.districttype = result;

            this.district_type_data.push({ value: '', text: 'Select District' });

            for (let i = 0; i < this.districttype.length; i++) {
                this.district_type_data.push({ value: this.districttype[i].id, text: this.districttype[i].name });
            }

            this.district_type = { text: 'Select District', value: '' };

            //this.getCompanyType();
        }, (err) => {
            this.loading.dismiss();
            let errJson = err.json();
            this.presentToast(errJson.message);
        });
    }
     getCompanyType() {
        this.showLoader();
        this.authService.getCompanyType().then((result) => {
            this.loading.dismiss();

            this.companytype = result;

            this.company_type_data.push({ value: '', text: 'Select Company' });

            for (let i = 0; i < this.companytype.length; i++) {
                this.company_type_data.push({ value: this.companytype[i].id, text: this.companytype[i].name });
            }

            this.company_type = { text: 'Select Company', value: '' };

           // this.getCompanyType();
        }, (err) => {
            this.loading.dismiss();
            let errJson = err.json();
            this.presentToast(errJson.message);
        });
    }
    saveAgencyData(){

      if (this.Name == undefined) {
             this.showAlert('Message', 'Please Select Name.');
            return;
        }
        if (this.Address == undefined) {
             this.showAlert('Message', 'Please Select Address.');
            return;
        }

        if (this.county_type == '') {
             this.showAlert('Message', 'Please Select County Name.');
            return;
        }
         if (this.state_type == '') {
             this.showAlert('Message', 'Please Select State Name.');
            return;
        }
        if (this.district_type == '') {
             this.showAlert('Message', 'Please Select District Name.');
            return;
        }
        if (this.City == undefined) {
             this.showAlert('Message', 'Please Select City.');
            return;
        }
         if (this.Email == undefined) {
             this.showAlert('Message', 'Please Select Email.');
            return;
        }
         if (this.Website == undefined) {
             this.showAlert('Message', 'Please Select Website.');
            return;
        }
         if (this.company_type == '') {
             this.showAlert('Message', 'Please Select Company Name.');
            return;
        }

        this.showLoader();

       
        this.AgencyReq.code = this.Code;
        this.AgencyReq.name = this.Name;
        this.AgencyReq.full_name = this.fullName;
        this.AgencyReq.address = this.Address;
        this.AgencyReq.pin_code = this.pinCode;
        this.AgencyReq.county_type = this.county_type.value;
        this.AgencyReq.state_type = this.state_type.value;
        this.AgencyReq.district_type = this.district_type.value;
        this.AgencyReq.city = this.City;
        this.AgencyReq.contact_no = this.contactNo;
        this.AgencyReq.email = this.Email;
        this.AgencyReq.website = this.Website;
        this.AgencyReq.company_type = this.company_type.value;
  
     
        this.authService.saveAgencyData(this.AgencyReq).then((result) => {
           this.loading.dismiss();

           this.showAlert('success', 'Agency Created successfully!');
                this.closeModal();
          }, (err) => {
            this.loading.dismiss();
            let errJson = err.json();
            this.presentToast(errJson.message);
        });

    }
     public closeModal() {

        this.viewCtrl.dismiss();
    }
     showLoader() {
        this.loading = this.loadingCtrl.create({
            content: 'Loading...'
        });

        this.loading.present();
    }

    presentToast(msg) {
        let toast = this.toastCtrl.create({
            message: msg,
            duration: 3000,
            position: 'bottom',
            dismissOnPageChange: true
        });

        toast.onDidDismiss(() => {
            //console.log('Dismissed toast');
        });

        toast.present();
    }

    showAlert(title, text) {
        //this.loading.dismiss();

        let alert = this.alertCtrl.create({
            title: title,
            subTitle: text,
            buttons: ['OK']
        });
        alert.present(prompt);
    }
    

}
