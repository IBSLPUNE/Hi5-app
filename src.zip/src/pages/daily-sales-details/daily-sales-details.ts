import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ViewController } from 'ionic-angular';

/**
 * Generated class for the DailySalesDetailsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-daily-sales-details',
  templateUrl: 'daily-sales-details.html',
})
export class DailySalesDetailsPage {

  req_data = {
			id: '',
			distributor_id: '',
			sub_distributor_id : '',
			date: '',
			name: '',
			description: '',
			area: '',
			agent_first: '',
			agent_last: '',
			address: '',
			primary_sell: '',
			secondary_sell: '',
			status:''
			};



  constructor(public navCtrl: NavController, public navParams: NavParams, public viewCtrl : ViewController) {
  }

  ionViewDidLoad() {
        this.req_data.id = this.navParams.get('id');
		this.req_data.distributor_id = this.navParams.get('distributor_id');
		this.req_data.sub_distributor_id = this.navParams.get('sub_distributor_id');
		this.req_data.date = this.navParams.get('date');
		this.req_data.name = this.navParams.get('name');
		this.req_data.description = this.navParams.get('description');
		this.req_data.agent_first = this.navParams.get('agent_first');
		this.req_data.agent_last = this.navParams.get('agent_last');
		this.req_data.area = this.navParams.get('area');
		this.req_data.address = this.navParams.get('address');
		this.req_data.primary_sell = this.navParams.get('primary_sell');
		this.req_data.secondary_sell = this.navParams.get('secondary_sell');
		this.req_data.status = this.navParams.get('status');
		
        console.log('ionViewDidLoad DailySalesDetailsPage');
  }
  
	public closeModal(){
		this.viewCtrl.dismiss();
	}

}
