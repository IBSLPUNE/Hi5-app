import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { UpdatedapkPage } from './updatedapk';

@NgModule({
  declarations: [
    UpdatedapkPage,
  ],
  imports: [
    IonicPageModule.forChild(UpdatedapkPage),
  ],
})
export class UpdatedapkPageModule {}
