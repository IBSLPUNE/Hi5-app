import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController, AlertController, ToastController, ViewController  } from 'ionic-angular';
import { AuthServiceProvider } from '../../providers/auth-service/auth-service';
/**
 * Generated class for the DistributorPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-distributor',
  templateUrl: 'distributor.html',
})
export class DistributorPage {

   loading: any;

   agency_type_data: Array<{ value: string, text: string }> = [];
   agency_type: any;
   agencytype: any;

   Name: any;
   Area: any;
   Distributortype: any;
   Description: any;
   Address: any;
   
   DistributorReq = { agency_type: '', name: '', area: '', distributortype: '', description: '', address: ''}

  constructor(public navCtrl: NavController, public navParams: NavParams, private alertCtrl: AlertController, private authService: AuthServiceProvider, public loadingCtrl: LoadingController, private toastCtrl: ToastController, public viewCtrl: ViewController) {
  this.getAgency();
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad DistributorPage');
  }
   getAgency() {
      //  this.showLoader();
        this.authService.getAgency().then((result) => {
         //   this.loading.dismiss();

            this.agencytype = result;

            this.agency_type_data.push({ value: '', text: 'Select ASE/SO' });

            for (let i = 0; i < this.agencytype.length; i++) {
                this.agency_type_data.push({ value: this.agencytype[i].id, text: this.agencytype[i].name });
            }

            this.agency_type = { text: 'Select ASE/SO', value: '' };

           //this.getAllEventType();
        }, (err) => {
            this.loading.dismiss();
            let errJson = err.json();
            this.presentToast(errJson.message);
        });
    }
   saveDistributorData(){

  
     this.showLoader();
       
      
        this.DistributorReq.name = this.Name;
        this.DistributorReq.area = this.Area;
        this.DistributorReq.distributortype = this.Distributortype;
        this.DistributorReq.description = this.Description;
        this.DistributorReq.address = this.Address;
        this.DistributorReq.agency_type = localStorage.getItem('agency_id');
  
     
        this.authService.saveDistributorData(this.DistributorReq).then((result) => {
             this.loading.dismiss();

            this.showAlert('success', 'Distributor Added Successfully');
                this.closeModal();
          }, (err) => {
            this.loading.dismiss();
            let errJson = err.json();
            this.presentToast(errJson.message);
        });

    }
     public closeModal() {

        this.viewCtrl.dismiss();
    }
     compareFn(option1: any, option2: any) {
        return option1.value === option2.value;
    }
      showLoader() {
        this.loading = this.loadingCtrl.create({
            content: 'Loading...'
        });

        this.loading.present();
    }

   presentToast(msg) {
        let toast = this.toastCtrl.create({
            message: msg,
            duration: 3000,
            position: 'bottom',
            dismissOnPageChange: true
        });

        toast.onDidDismiss(() => {
            //console.log('Dismissed toast');
        });

        toast.present();
    }


    showAlert(title, text) {
        //this.loading.dismiss();

        let alert = this.alertCtrl.create({
            title: title,
            subTitle: text,
            buttons: ['OK']
        });
        alert.present(prompt);
    }


}
