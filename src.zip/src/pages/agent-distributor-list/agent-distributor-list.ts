import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController, ToastController, ModalController, AlertController, PopoverController } from 'ionic-angular';
import { AuthServiceProvider } from '../../providers/auth-service/auth-service';
/**
 * Generated class for the AgentDistributorListPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-agent-distributor-list',
  templateUrl: 'agent-distributor-list.html',
})
export class AgentDistributorListPage {

  loading: any;
   distributor_data: any;
  


  constructor(public navCtrl: NavController, public navParams: NavParams, private authService: AuthServiceProvider, public loadingCtrl: LoadingController, private toastCtrl: ToastController, private modalCtrl: ModalController, public alertCtrl: AlertController, public popoverCtrl: PopoverController) {
  this.getagentwisedistributorlist();
        
  }

  ionViewDidLoad() {
   
  }
  getagentwisedistributorlist(){
   //this.showLoader();
            this.authService.getagentwisedistributorlist(localStorage.getItem('agent_id')).then((result) => {
           // this.loading.dismiss();
            this.distributor_data = result;
        }, (err) => {
            this.loading.dismiss();
            let errJson = err.json();
            this.presentToast(errJson.message);
        });
    }
 showLoader() {
        this.loading = this.loadingCtrl.create({
            content: 'Loading...'
        });

        this.loading.present();
    }

    presentToast(msg) {
        let toast = this.toastCtrl.create({
            message: msg,
            duration: 3000,
            position: 'bottom',
            dismissOnPageChange: true
        });

        toast.onDidDismiss(() => {
            //console.log('Dismissed toast');
        });
        toast.present();
    }

  
     
 
    showModalDialog(req_data){
      var data = {
            id: req_data.id
            }
     var MemberRequestPagemodalPage = this.modalCtrl.create('AgentDistributorPage', data);
      
       
        MemberRequestPagemodalPage.onDidDismiss(data => {
        
            this.getagentwisedistributorlist();  
        });
        MemberRequestPagemodalPage.present();
    
    }
}
