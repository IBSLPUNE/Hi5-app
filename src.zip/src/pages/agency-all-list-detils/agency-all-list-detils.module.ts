import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AgencyAllListDetilsPage } from './agency-all-list-detils';

@NgModule({
  declarations: [
    AgencyAllListDetilsPage,
  ],
  imports: [
    IonicPageModule.forChild(AgencyAllListDetilsPage),
  ],
})
export class AgencyAllListDetilsPageModule {}
