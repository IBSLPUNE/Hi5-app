import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController, ToastController, ModalController, AlertController, PopoverController } from 'ionic-angular';
import { AuthServiceProvider } from '../../providers/auth-service/auth-service';

import { DailySalesDetailsPage } from '../daily-sales-details/daily-sales-details';
/**
 * Generated class for the DailySalesListPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-daily-sales-list',
  templateUrl: 'daily-sales-list.html',
})
export class DailySalesListPage {

   loading: any;
   daily_sales_data: any;
   
  constructor(public navCtrl: NavController, public navParams: NavParams, private authService: AuthServiceProvider, public loadingCtrl: LoadingController, private toastCtrl: ToastController, private modalCtrl: ModalController, public alertCtrl: AlertController, public popoverCtrl: PopoverController) {
        
  }

  ionViewDidLoad() {
      this.getDailySalesList();
  }
  getDailySalesList(){
   this.showLoader();
            this.authService.getDailySalesList().then((result) => {
            this.loading.dismiss();
            this.daily_sales_data = result;
        }, (err) => {
            this.loading.dismiss();
            let errJson = err.json();
            this.presentToast(errJson.message);
        });
    }
    showLoader() {
        this.loading = this.loadingCtrl.create({
            content: 'Loading...'
        });

        this.loading.present();
    }

    presentToast(msg) {
        let toast = this.toastCtrl.create({
            message: msg,
            duration: 3000,
            position: 'bottom',
            dismissOnPageChange: true
        });

        toast.onDidDismiss(() => {
            //console.log('Dismissed toast');
        });
        toast.present();
    }
    showModalDialog(dsd){
      var data = {id:dsd.id,
                 date:dsd.date
                }

      var EventRequestPagemodalPage = this.modalCtrl.create('DailySaleDatewiseListPage', data);
      
       
        EventRequestPagemodalPage.onDidDismiss(data => {
         this.getDailySalesList();
    
           
        });
        EventRequestPagemodalPage.present();
    }

    showDistributorRequest(){
      var EventRequestPagemodalPage = this.modalCtrl.create('DailySalesPage');
      
       
        EventRequestPagemodalPage.onDidDismiss(data => {
         this.getDailySalesList();
    
           
        });
        EventRequestPagemodalPage.present();
    }
}
