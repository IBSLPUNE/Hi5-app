import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DailySaleDatewiseListPage } from './daily-sale-datewise-list';

@NgModule({
  declarations: [
    DailySaleDatewiseListPage,
  ],
  imports: [
    IonicPageModule.forChild(DailySaleDatewiseListPage),
  ],
})
export class DailySaleDatewiseListPageModule {}
