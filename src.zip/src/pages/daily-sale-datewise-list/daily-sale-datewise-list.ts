import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController, ToastController, ModalController, AlertController, PopoverController, ViewController } from 'ionic-angular';
import { AuthServiceProvider } from '../../providers/auth-service/auth-service';
import { DailySalesDetailsPage } from '../daily-sales-details/daily-sales-details';

/**
 * Generated class for the DailySaleDatewiseListPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-daily-sale-datewise-list',
  templateUrl: 'daily-sale-datewise-list.html',
})
export class DailySaleDatewiseListPage {
  loading: any;
  dailyId: any;
  dailydate: any;
  daily_sales_data: any;


   
  constructor(public navCtrl: NavController, public navParams: NavParams, private authService: AuthServiceProvider, public loadingCtrl: LoadingController, private toastCtrl: ToastController, private modalCtrl: ModalController, public alertCtrl: AlertController, public popoverCtrl: PopoverController, public viewCtrl : ViewController) {
   this.dailyId = this.navParams.get('id');
   this.dailydate = this.navParams.get('date');
   this.getDailySalesListDateWise();
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad DailySaleDatewiseListPage');
  }
  getDailySalesListDateWise(){
   this.showLoader();
            this.authService.getDailySalesListDateWise(this.dailydate).then((result) => {
            this.loading.dismiss();
            this.daily_sales_data = result;
        }, (err) => {
            this.loading.dismiss();
            let errJson = err.json();
            this.presentToast(errJson.message);
        });
    }
     showLoader() {
        this.loading = this.loadingCtrl.create({
            content: 'Loading...'
        });

        this.loading.present();
    }

    presentToast(msg) {
        let toast = this.toastCtrl.create({
            message: msg,
            duration: 3000,
            position: 'bottom',
            dismissOnPageChange: true
        });

        toast.onDidDismiss(() => {
            //console.log('Dismissed toast');
        });
        toast.present();
    }
    public closeModal(){
		this.viewCtrl.dismiss();
	}
    showModalDialog(req_data) {
       var data = {
              id: req_data.id,
              distributor_id: req_data.distributor_id,
              sub_distributor_id: req_data.sub_distributor_id,
              date: req_data.date,
              name: req_data.name,
              description: req_data.description,
              area: req_data.area,
              address: req_data.address,
              primary_sell: req_data.primary_sell,
              secondary_sell: req_data.secondary_sell,
              status: req_data.status,
              agent_first: req_data.agent_first,
              agent_last: req_data.agent_last
         };
       
        var DetailsmodalPage = this.popoverCtrl.create(DailySalesDetailsPage, data, { cssClass: 'clsPopup' });
        DetailsmodalPage.present();
    }
     cancelDailySaleRequest(daily_sale_id) {
       // this.showLoader();
        this.authService.cancelDailySaleRequest(daily_sale_id).then((result) => {
            //this.loading.dismiss();

            this.getDailySalesListDateWise();
        }, (err) => {
            this.loading.dismiss();
            let errJson = err.json();
            this.presentToast(errJson.message);
        });
    }
     presentConfirm(daily_sale_id) {
        const alert = this.alertCtrl.create({
            title: 'Confirmation',
            message: 'Are you sure?',
            buttons: [
                {
                    text: 'Ok',
                    handler: () => {
                        console.log('Ok clicked');
                        this.cancelDailySaleRequest(daily_sale_id);
                    }
                },
                {
                    text: 'Cancel',
                    role: 'cancel',
                    handler: () => {
                        console.log('Cancel clicked');
                    }
                }
            ]
        });
        alert.present();
    }
  

}
