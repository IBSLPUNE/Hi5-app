import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, LoadingController, AlertController, ToastController, ViewController  } from 'ionic-angular';
import { AuthServiceProvider } from '../../providers/auth-service/auth-service';
import moment from 'moment';
/**
 * Generated class for the DailySalesPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-daily-sales',
  templateUrl: 'daily-sales.html',
})
export class DailySalesPage {
   
   loading: any;

   distributor_type_data: Array<{ value: string, text: string }> = [];
   distributor_type: any;
   distributortype: any;

   sub_distributor_type_data: Array<{ value: string, text: string }> = [];
   sub_distributor_type: any;
   subdistributortype: any;

   Name: any;
   Area: any;
   Description: any;
   Address: any;
   PrimarySell: any;
   SecondarySell: any;

   AgentdistributorReq = {agent_id: '', distributor_type: '', sub_distributor_type: '', name: '', area: '', description: '', 
   address: '', primary_sell: '', seconary_sell: '', current_date: '', status: true}

  constructor(public navCtrl: NavController, public navParams: NavParams, private alertCtrl: AlertController, private authService: AuthServiceProvider, public loadingCtrl: LoadingController, private toastCtrl: ToastController, public viewCtrl: ViewController) {
         this.getDistributorType();
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad DailySalesPage');
  }
   getDistributorType() {
       // this.showLoader();
        this.authService.getDistributorType(localStorage.getItem('agent_id')).then((result) => {
           // this.loading.dismiss();

            this.distributortype = result;

            this.distributor_type_data.push({ value: '', text: 'Select Distributor' });

            for (let i = 0; i < this.distributortype.length; i++) {
                this.distributor_type_data.push({ value: this.distributortype[i].id, text: this.distributortype[i].name });
            }

            this.distributor_type = { text: 'Select Distributor', value: '' };

       
        }, (err) => {
            this.loading.dismiss();
            let errJson = err.json();
            this.presentToast(errJson.message, false);
        });
    }
     getSubDistributorType() {
        //this.showLoader();
        this.authService.getSubDistributorType(this.distributor_type.value).then((result) => {
           // this.loading.dismiss();

            this.subdistributortype = result;

            this.sub_distributor_type_data.push({ value: '', text: 'Select Sub-Distributor' });

            for (let i = 0; i < this.subdistributortype.length; i++) {
                this.sub_distributor_type_data.push({ value: this.subdistributortype[i].id, text: this.subdistributortype[i].name });
            }

            this.sub_distributor_type = { text: 'Select Sub-Distributor', value: '' };

     
        }, (err) => {
            this.loading.dismiss();
            let errJson = err.json();
            this.presentToast(errJson.message, false);
        });
    }
      compareFn(option1: any, option2: any) {
        return option1.value === option2.value;
    }
    saveDisributorRequest(){

        if (this.distributor_type.value == '') {
             this.showAlert('Message', 'Please Select Distributor Name.');
            return;
        }
        
        if (this.sub_distributor_type.value == '') {
             this.showAlert('Message', 'Please Select Sub Distributor Name.');
            return;
        }
      
    
        //this.showLoader();
        var now = new Date();
       
        this.AgentdistributorReq.name = this.Name;
        this.AgentdistributorReq.area = this.Area;
        this.AgentdistributorReq.description = this.Description;
        this.AgentdistributorReq.address = this.Address;
        this.AgentdistributorReq.distributor_type = this.distributor_type.value;
        this.AgentdistributorReq.sub_distributor_type = this.sub_distributor_type.value;
        this.AgentdistributorReq.primary_sell = this.PrimarySell;
        this.AgentdistributorReq.seconary_sell = this.SecondarySell;
        this.AgentdistributorReq.current_date = moment(now).format('YYYY-MM-DD');
        this.AgentdistributorReq.agent_id = localStorage.getItem('agent_id');
        this.AgentdistributorReq.status = true;
 
        this.authService.saveDisributorRequest(this.AgentdistributorReq).then((result) => {
           // this.loading.dismiss();

           let bDismiss = false;
                if (result["status"].toLowerCase().indexOf('success') >= 0) {
                this.showAlert('success', result["status"]);
                 this.closeModal();
                } 
                else
                {
                this.showAlert('success', result["status"]);
                }
                
          }, (err) => {
            this.loading.dismiss();
            let errJson = err.json();
            this.presentToast(errJson.message, false);
        });

    }
     public closeModal() {

        this.viewCtrl.dismiss();
    }
     showLoader() {
        this.loading = this.loadingCtrl.create({
            content: 'Loading...'
        });

        this.loading.present();
    }


     presentToast(msg, bDismiss) {
        let toast = this.toastCtrl.create({
            message: msg,
            duration: 3000,
            position: 'bottom'/*,
            dismissOnPageChange: true*/
        });
        toast.onDidDismiss(() => {
            if (bDismiss == true) {
               // this.dismiss();
                this.closeModal();
            }
            //console.log('Dismissed toast');
        });

        toast.present();

    }

    showAlert(title, text) {
        //this.loading.dismiss();

        let alert = this.alertCtrl.create({
            title: title,
            subTitle: text,
            buttons: ['OK']
        });
        alert.present(prompt);
    }

}
