import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DailySalesPage } from './daily-sales';

@NgModule({
  declarations: [
    DailySalesPage,
  ],
  imports: [
    IonicPageModule.forChild(DailySalesPage),
  ],
})
export class DailySalesPageModule {}
