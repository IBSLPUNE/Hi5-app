import { BrowserModule} from '@angular/platform-browser';
import { ErrorHandler, NgModule } from '@angular/core';
import { IonicApp, IonicErrorHandler, IonicModule } from 'ionic-angular';
import { SplashScreen } from '@ionic-native/splash-screen';
import { StatusBar } from '@ionic-native/status-bar';
 import { IonicStorageModule } from '@ionic/storage';
 import { HttpClientModule } from '@angular/common/http';
 import { HttpModule } from '@angular/http';

import { MyApp } from './app.component';
import { HomePage } from '../pages/home/home';
import { LoginPage } from '../pages/login/login';
import { EmployeeAllListPage } from '../pages/employee-all-list/employee-all-list';
import { AgencyAllListPage } from '../pages/agency-all-list/agency-all-list';
import { AgencyAllListDetilsPage } from '../pages/agency-all-list-detils/agency-all-list-detils';
import { EventAllListPage } from '../pages/event-all-list/event-all-list';
import { PartialMenuPage } from '../pages/partial-menu/partial-menu';
import { AgencyProfilePage } from '../pages/agency-profile/agency-profile';
import { UserInfoDetailsPage } from '../pages/user-info-details/user-info-details';
import { AgentProfilePage } from '../pages/agent-profile/agent-profile';
import { ParticularEventListPage } from '../pages/particular-event-list/particular-event-list';
import { CompanyProfilePage } from '../pages/company-profile/company-profile';
import { MemberDetailsPage } from '../pages/member-details/member-details';
import { AdminAllEventsShowPage } from '../pages/admin-all-events-show/admin-all-events-show';
import { AdminAgentPage } from '../pages/admin-agent/admin-agent';
import { AdminAllEventDetailPage } from '../pages/admin-all-event-detail/admin-all-event-detail';
import { AdminEventListPage } from '../pages/admin-event-list/admin-event-list';
import { EventTextDataPage } from '../pages/event-text-data/event-text-data';
import { EmployeeAllListDetailsPage } from '../pages/employee-all-list-details/employee-all-list-details';
import { DistributorListPage } from '../pages/distributor-list/distributor-list';
import { DistributorDetailsPage } from '../pages/distributor-details/distributor-details';
import { SubDistributorListPage } from '../pages/sub-distributor-list/sub-distributor-list';
import { SubDistributorDetailsPage } from '../pages/sub-distributor-details/sub-distributor-details';
import { AgentDistributorListPage } from '../pages/agent-distributor-list/agent-distributor-list';
import { DailySalesListPage } from '../pages/daily-sales-list/daily-sales-list';
import { DailySalesDetailsPage } from '../pages/daily-sales-details/daily-sales-details';
import { ZoneListPage } from '../pages/zone-list/zone-list';
import { ZoneDetailsPage } from '../pages/zone-details/zone-details';

import { AuthServiceProvider } from '../providers/auth-service/auth-service';
import { DatePickerModule } from 'ion-datepicker';
import { MomentModule } from 'angular2-moment';
import { FileTransfer, FileTransferObject } from '@ionic-native/file-transfer';
import { File } from '@ionic-native/file';
import { InAppBrowser } from '@ionic-native/in-app-browser';
import { NgxPaginationModule } from 'ngx-pagination';
import { AgencyNamePipe } from '../pipes/agency-name/agency-name';
import { AgentNamePipe } from '../pipes/agent-name/agent-name';
import { EventNamePipe } from '../pipes/event-name/event-name'



@NgModule({
  declarations: [
    MyApp,
    HomePage,
    LoginPage,
    EmployeeAllListPage,
    AgencyAllListPage,
    AgencyAllListDetilsPage,
    EventAllListPage,
    EmployeeAllListDetailsPage,
    PartialMenuPage,
    AgencyProfilePage,
    UserInfoDetailsPage,
    AgentProfilePage,
    ParticularEventListPage,
    CompanyProfilePage,
    MemberDetailsPage,
    AdminAgentPage,
    AdminAllEventsShowPage,
    AdminAllEventDetailPage,
    AdminEventListPage,
    EventTextDataPage,
    AgencyNamePipe,
    AgentNamePipe,
    EventNamePipe,
    DistributorListPage,
    SubDistributorListPage,
    DistributorDetailsPage,
    SubDistributorDetailsPage,
    AgentDistributorListPage,
    DailySalesListPage,
    DailySalesDetailsPage,
    ZoneListPage,
    ZoneDetailsPage
   

  ],
  imports: [
    BrowserModule,
    IonicModule.forRoot(MyApp),
    HttpModule,
    IonicStorageModule.forRoot(),
    HttpClientModule,
    DatePickerModule,
    MomentModule,
    NgxPaginationModule,
    

  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    HomePage,
    LoginPage,
    EmployeeAllListPage,
    AgencyAllListPage,
    AgencyAllListDetilsPage,
    EventAllListPage,
    PartialMenuPage,
    AgencyProfilePage,
    UserInfoDetailsPage,
    AgentProfilePage,
    ParticularEventListPage,
    CompanyProfilePage,
    MemberDetailsPage,
    AdminAgentPage,
    AdminAllEventsShowPage,
    AdminAllEventDetailPage,
    AdminEventListPage,
    EventTextDataPage,
    EmployeeAllListDetailsPage,
    DistributorListPage,
    SubDistributorListPage,
    DistributorDetailsPage,
    SubDistributorDetailsPage,
    AgentDistributorListPage,
    DailySalesListPage,
    DailySalesDetailsPage,
    ZoneListPage,
    ZoneDetailsPage
  ],
  providers: [
    StatusBar,
    SplashScreen,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    AuthServiceProvider,
    FileTransfer,
   //FileUploadOptions, 
    FileTransferObject,
    File,
    InAppBrowser
  ]
})
export class AppModule {}
